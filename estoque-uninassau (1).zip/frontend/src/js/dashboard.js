// Funções para o dashboard
document.addEventListener('DOMContentLoaded', function() {
  // Verificar autenticação
  if (!checkAuth()) {
    return;
  }
  
  // Carregar dados do usuário
  const user = getCurrentUser();
  if (user) {
    document.getElementById('userName').textContent = user.nome;
  }
  
  // Configurar evento de logout
  document.getElementById('btnLogout').addEventListener('click', function(e) {
    e.preventDefault();
    logout();
  });
  
  document.getElementById('menuLogout').addEventListener('click', function(e) {
    e.preventDefault();
    logout();
  });
  
  // Carregar dados do dashboard (simulação)
  loadDashboardData();
  
  // Inicializar gráficos
  initCharts();
});

// Função para carregar dados do dashboard (simulação)
function loadDashboardData() {
  // Simulação de dados - em produção, estes dados viriam da API
  document.getElementById('totalProdutos').textContent = '157';
  document.getElementById('baixoEstoque').textContent = '12';
  document.getElementById('produtosVencidos').textContent = '5';
  document.getElementById('movimentacoes').textContent = '43';
  
  // Aqui seria feita uma chamada à API para obter dados reais
  // fetchDashboardData();
}

// Função para inicializar gráficos
function initCharts() {
  // Gráfico de distribuição de estoque
  const ctx = document.getElementById('estoqueChart').getContext('2d');
  
  // Dados simulados para o gráfico
  const data = {
    labels: ['Eletrônicos', 'Alimentos', 'Limpeza', 'Escritório', 'Outros'],
    datasets: [{
      label: 'Quantidade em Estoque',
      data: [65, 40, 25, 20, 7],
      backgroundColor: [
        'rgba(52, 152, 219, 0.7)',
        'rgba(46, 204, 113, 0.7)',
        'rgba(155, 89, 182, 0.7)',
        'rgba(241, 196, 15, 0.7)',
        'rgba(230, 126, 34, 0.7)'
      ],
      borderColor: [
        'rgba(52, 152, 219, 1)',
        'rgba(46, 204, 113, 1)',
        'rgba(155, 89, 182, 1)',
        'rgba(241, 196, 15, 1)',
        'rgba(230, 126, 34, 1)'
      ],
      borderWidth: 1
    }]
  };
  
  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom',
      },
      title: {
        display: true,
        text: 'Distribuição por Categoria'
      }
    }
  };
  
  new Chart(ctx, {
    type: 'pie',
    data: data,
    options: options
  });
}

// Função para buscar dados do dashboard da API
async function fetchDashboardData() {
  try {
    const token = getToken();
    
    const response = await fetch(`${API_URL}/dashboard`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    if (!response.ok) {
      throw new Error('Erro ao carregar dados do dashboard');
    }
    
    const data = await response.json();
    
    // Atualizar elementos da UI com os dados recebidos
    document.getElementById('totalProdutos').textContent = data.totalProdutos;
    document.getElementById('baixoEstoque').textContent = data.baixoEstoque;
    document.getElementById('produtosVencidos').textContent = data.produtosVencidos;
    document.getElementById('movimentacoes').textContent = data.totalMovimentacoes;
    
    // Atualizar tabela de movimentações
    updateMovimentacoesTable(data.ultimasMovimentacoes);
    
    // Atualizar lista de alertas
    updateAlertasList(data.alertas);
    
  } catch (error) {
    console.error('Erro ao buscar dados do dashboard:', error);
  }
}

// Função para atualizar tabela de movimentações
function updateMovimentacoesTable(movimentacoes) {
  const tableBody = document.getElementById('movimentacoesTable');
  
  if (!movimentacoes || movimentacoes.length === 0) {
    return;
  }
  
  let html = '';
  
  movimentacoes.forEach(mov => {
    const tipoClass = mov.tipo === 'entrada' ? 'bg-success' : mov.tipo === 'saida' ? 'bg-danger' : 'bg-warning';
    const tipoText = mov.tipo === 'entrada' ? 'Entrada' : mov.tipo === 'saida' ? 'Saída' : 'Ajuste';
    
    html += `
      <tr>
        <td>${mov.produto}</td>
        <td><span class="badge ${tipoClass}">${tipoText}</span></td>
        <td>${mov.quantidade}</td>
        <td>${mov.responsavel}</td>
        <td>${formatDate(mov.data)}</td>
      </tr>
    `;
  });
  
  tableBody.innerHTML = html;
}

// Função para atualizar lista de alertas
function updateAlertasList(alertas) {
  const alertasList = document.getElementById('alertasList');
  
  if (!alertas || alertas.length === 0) {
    return;
  }
  
  let html = '';
  
  alertas.forEach(alerta => {
    const tipoClass = alerta.tipo === 'estoque' ? 'bg-warning' : alerta.tipo === 'vencimento' ? 'bg-danger' : 'bg-success';
    const tipoText = alerta.tipo === 'estoque' ? 'Estoque' : alerta.tipo === 'vencimento' ? 'Vencimento' : 'Entrada';
    
    html += `
      <div class="list-group-item d-flex justify-content-between align-items-center p-3">
        <div>
          <div class="d-flex align-items-center">
            <span class="badge ${tipoClass} me-2">${tipoText}</span>
            <h6 class="mb-0">${alerta.mensagem}</h6>
          </div>
          <small class="text-muted">${formatDate(alerta.data)}</small>
        </div>
      </div>
    `;
  });
  
  alertasList.innerHTML = html;
}

// Função auxiliar para formatar data
function formatDate(dateString) {
  const date = new Date(dateString);
  return date.toLocaleDateString('pt-BR');
}
