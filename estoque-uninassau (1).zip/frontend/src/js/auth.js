// Funções de autenticação
const API_URL = 'http://localhost:5000/api';

// Verificar se o usuário está logado
function checkAuth() {
  const token = localStorage.getItem('userToken');
  if (!token) {
    // Se estiver em uma página protegida, redirecionar para login
    if (window.location.pathname !== '/' && window.location.pathname !== '/index.html') {
      window.location.href = '/';
    }
    return false;
  }
  
  // Se estiver na página de login e já estiver autenticado, redirecionar para dashboard
  if (window.location.pathname === '/' || window.location.pathname === '/index.html') {
    window.location.href = '/dashboard.html';
  }
  return true;
}

// Função para login
async function login(email, senha) {
  try {
    const response = await fetch(`${API_URL}/users/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email, senha }),
    });

    const data = await response.json();
    
    if (!response.ok) {
      throw new Error(data.message || 'Erro ao fazer login');
    }
    
    // Salvar dados do usuário e token
    localStorage.setItem('userToken', data.token);
    localStorage.setItem('userData', JSON.stringify({
      id: data._id,
      nome: data.nome,
      email: data.email,
      cargo: data.cargo,
      departamento: data.departamento,
      role: data.role
    }));
    
    // Redirecionar para dashboard
    window.location.href = '/dashboard.html';
    
  } catch (error) {
    console.error('Erro de login:', error);
    return { error: error.message };
  }
}

// Função para registro
async function register(userData) {
  try {
    const response = await fetch(`${API_URL}/users/register`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(userData),
    });

    const data = await response.json();
    
    if (!response.ok) {
      throw new Error(data.message || 'Erro ao registrar usuário');
    }
    
    // Salvar dados do usuário e token
    localStorage.setItem('userToken', data.token);
    localStorage.setItem('userData', JSON.stringify({
      id: data._id,
      nome: data.nome,
      email: data.email,
      cargo: data.cargo,
      departamento: data.departamento,
      role: data.role
    }));
    
    // Redirecionar para dashboard
    window.location.href = '/dashboard.html';
    
  } catch (error) {
    console.error('Erro de registro:', error);
    return { error: error.message };
  }
}

// Função para logout
function logout() {
  localStorage.removeItem('userToken');
  localStorage.removeItem('userData');
  window.location.href = '/';
}

// Função para obter dados do usuário atual
function getCurrentUser() {
  const userData = localStorage.getItem('userData');
  return userData ? JSON.parse(userData) : null;
}

// Função para obter token
function getToken() {
  return localStorage.getItem('userToken');
}

// Função para verificar se o usuário é admin
function isAdmin() {
  const user = getCurrentUser();
  return user && user.role === 'admin';
}

// Função para atualizar perfil
async function updateProfile(userData) {
  try {
    const token = getToken();
    
    const response = await fetch(`${API_URL}/users/profile`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(userData),
    });

    const data = await response.json();
    
    if (!response.ok) {
      throw new Error(data.message || 'Erro ao atualizar perfil');
    }
    
    // Atualizar dados do usuário no localStorage
    localStorage.setItem('userData', JSON.stringify({
      id: data._id,
      nome: data.nome,
      email: data.email,
      cargo: data.cargo,
      departamento: data.departamento,
      role: data.role
    }));
    
    return { success: true, data };
    
  } catch (error) {
    console.error('Erro ao atualizar perfil:', error);
    return { error: error.message };
  }
}

// Eventos para página de login/registro
document.addEventListener('DOMContentLoaded', function() {
  // Verificar se estamos na página de login/registro
  const loginForm = document.getElementById('loginForm');
  const registerForm = document.getElementById('registerForm');
  
  if (loginForm && registerForm) {
    // Alternar entre formulários de login e registro
    document.getElementById('showRegister').addEventListener('click', function(e) {
      e.preventDefault();
      loginForm.classList.add('d-none');
      registerForm.classList.remove('d-none');
    });
    
    document.getElementById('showLogin').addEventListener('click', function(e) {
      e.preventDefault();
      registerForm.classList.add('d-none');
      loginForm.classList.remove('d-none');
    });
    
    // Processar formulário de login
    document.getElementById('formLogin').addEventListener('submit', async function(e) {
      e.preventDefault();
      
      const email = document.getElementById('email').value;
      const senha = document.getElementById('senha').value;
      const errorElement = document.getElementById('loginError');
      
      errorElement.classList.add('d-none');
      
      const result = await login(email, senha);
      
      if (result && result.error) {
        errorElement.textContent = result.error;
        errorElement.classList.remove('d-none');
      }
    });
    
    // Processar formulário de registro
    document.getElementById('formRegister').addEventListener('submit', async function(e) {
      e.preventDefault();
      
      const userData = {
        nome: document.getElementById('regNome').value,
        email: document.getElementById('regEmail').value,
        senha: document.getElementById('regSenha').value,
        cargo: document.getElementById('regCargo').value,
        departamento: document.getElementById('regDepartamento').value
      };
      
      const errorElement = document.getElementById('registerError');
      
      errorElement.classList.add('d-none');
      
      const result = await register(userData);
      
      if (result && result.error) {
        errorElement.textContent = result.error;
        errorElement.classList.remove('d-none');
      }
    });
  }
});
