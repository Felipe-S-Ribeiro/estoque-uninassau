// Funções para o perfil do usuário
document.addEventListener('DOMContentLoaded', function() {
  // Verificar autenticação
  if (!checkAuth()) {
    return;
  }
  
  // Carregar dados do usuário
  loadUserProfile();
  
  // Configurar evento de logout
  document.getElementById('btnLogout').addEventListener('click', function(e) {
    e.preventDefault();
    logout();
  });
  
  document.getElementById('menuLogout').addEventListener('click', function(e) {
    e.preventDefault();
    logout();
  });
  
  // Configurar formulário de atualização de perfil
  document.getElementById('formProfile').addEventListener('submit', function(e) {
    e.preventDefault();
    updateUserProfile();
  });
});

// Função para carregar dados do perfil
function loadUserProfile() {
  const user = getCurrentUser();
  
  if (user) {
    // Atualizar nome do usuário no header
    document.getElementById('userName').textContent = user.nome;
    
    // Atualizar informações do perfil
    document.getElementById('profileName').textContent = user.nome;
    document.getElementById('profileRole').textContent = `${user.cargo || 'Não informado'} - ${user.departamento || 'Não informado'}`;
    document.getElementById('profileEmail').textContent = user.email;
    document.getElementById('profileUserRole').textContent = user.role === 'admin' ? 'Administrador' : 'Usuário';
    
    // Preencher formulário de edição
    document.getElementById('profileEditName').value = user.nome;
    document.getElementById('profileEditEmail').value = user.email;
    document.getElementById('profileEditCargo').value = user.cargo || '';
    document.getElementById('profileEditDepartamento').value = user.departamento || '';
    
    // Buscar informações adicionais do usuário da API
    fetchUserDetails();
  }
}

// Função para buscar detalhes adicionais do usuário
async function fetchUserDetails() {
  try {
    const token = getToken();
    
    const response = await fetch(`${API_URL}/users/profile`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    if (!response.ok) {
      throw new Error('Erro ao carregar detalhes do usuário');
    }
    
    const data = await response.json();
    
    // Atualizar último acesso
    if (data.ultimoAcesso) {
      const date = new Date(data.ultimoAcesso);
      document.getElementById('profileLastAccess').textContent = date.toLocaleDateString('pt-BR') + ' ' + date.toLocaleTimeString('pt-BR');
    }
    
    // Carregar atividades recentes
    if (data.atividades && data.atividades.length > 0) {
      updateActivityTable(data.atividades);
    }
    
  } catch (error) {
    console.error('Erro ao buscar detalhes do usuário:', error);
  }
}

// Função para atualizar tabela de atividades
function updateActivityTable(atividades) {
  const tableBody = document.getElementById('activityTable');
  
  if (!atividades || atividades.length === 0) {
    return;
  }
  
  let html = '';
  
  atividades.forEach(atividade => {
    const tipoClass = atividade.tipo === 'entrada' ? 'bg-success' : atividade.tipo === 'saida' ? 'bg-danger' : 'bg-warning';
    const tipoText = atividade.tipo === 'entrada' ? 'Entrada' : atividade.tipo === 'saida' ? 'Saída' : 'Ajuste';
    
    html += `
      <tr>
        <td><span class="badge ${tipoClass}">${tipoText}</span></td>
        <td>${atividade.produto}</td>
        <td>${atividade.quantidade}</td>
        <td>${formatDate(atividade.data)}</td>
      </tr>
    `;
  });
  
  tableBody.innerHTML = html;
}

// Função para atualizar perfil do usuário
async function updateUserProfile() {
  const nome = document.getElementById('profileEditName').value;
  const email = document.getElementById('profileEditEmail').value;
  const cargo = document.getElementById('profileEditCargo').value;
  const departamento = document.getElementById('profileEditDepartamento').value;
  const senha = document.getElementById('profileEditSenha').value;
  const confirmSenha = document.getElementById('profileEditConfirmSenha').value;
  
  // Validar campos
  if (!nome || !email) {
    showProfileError('Nome e email são obrigatórios');
    return;
  }
  
  // Validar senhas
  if (senha && senha !== confirmSenha) {
    showProfileError('As senhas não coincidem');
    return;
  }
  
  // Preparar dados para atualização
  const userData = {
    nome,
    email,
    cargo,
    departamento
  };
  
  // Adicionar senha apenas se foi informada
  if (senha) {
    userData.senha = senha;
  }
  
  try {
    const result = await updateProfile(userData);
    
    if (result.error) {
      showProfileError(result.error);
    } else {
      showProfileSuccess();
      
      // Atualizar informações exibidas
      document.getElementById('profileName').textContent = nome;
      document.getElementById('profileRole').textContent = `${cargo || 'Não informado'} - ${departamento || 'Não informado'}`;
      document.getElementById('profileEmail').textContent = email;
      document.getElementById('userName').textContent = nome;
      
      // Limpar campos de senha
      document.getElementById('profileEditSenha').value = '';
      document.getElementById('profileEditConfirmSenha').value = '';
    }
  } catch (error) {
    showProfileError('Erro ao atualizar perfil');
    console.error(error);
  }
}

// Função para exibir mensagem de sucesso
function showProfileSuccess() {
  const successElement = document.getElementById('profileSuccess');
  const errorElement = document.getElementById('profileError');
  
  errorElement.classList.add('d-none');
  successElement.classList.remove('d-none');
  
  // Esconder mensagem após 3 segundos
  setTimeout(() => {
    successElement.classList.add('d-none');
  }, 3000);
}

// Função para exibir mensagem de erro
function showProfileError(message) {
  const successElement = document.getElementById('profileSuccess');
  const errorElement = document.getElementById('profileError');
  
  successElement.classList.add('d-none');
  errorElement.textContent = message;
  errorElement.classList.remove('d-none');
}

// Função auxiliar para formatar data
function formatDate(dateString) {
  const date = new Date(dateString);
  return date.toLocaleDateString('pt-BR');
}
