// Funções para gerenciamento de relatórios
document.addEventListener('DOMContentLoaded', function() {
  // Verificar autenticação
  if (!checkAuth()) {
    return;
  }
  
  // Carregar dados do usuário
  const user = getCurrentUser();
  if (user) {
    document.getElementById('userName').textContent = user.nome;
  }
  
  // Configurar evento de logout
  document.getElementById('btnLogout').addEventListener('click', function(e) {
    e.preventDefault();
    logout();
  });
  
  document.getElementById('menuLogout').addEventListener('click', function(e) {
    e.preventDefault();
    logout();
  });
  
  // Carregar categorias para o filtro de relatório de estoque
  loadCategories();
  
  // Carregar produtos para o filtro de relatório de movimentações
  loadProducts();
  
  // Configurar formulários de relatórios
  document.getElementById('formStockReport').addEventListener('submit', function(e) {
    e.preventDefault();
    generateStockReport();
  });
  
  document.getElementById('formMovementsReport').addEventListener('submit', function(e) {
    e.preventDefault();
    generateMovementsReport();
  });
  
  document.getElementById('formExpiryReport').addEventListener('submit', function(e) {
    e.preventDefault();
    generateExpiryReport();
  });
});

// Função para carregar categorias
async function loadCategories() {
  try {
    const token = getToken();
    
    const response = await fetch(`${API_URL}/products/categories`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    if (!response.ok) {
      throw new Error('Erro ao carregar categorias');
    }
    
    const categories = await response.json();
    
    const selectElement = document.getElementById('stockCategory');
    
    // Manter a opção "Todas as categorias"
    selectElement.innerHTML = '<option value="">Todas as categorias</option>';
    
    // Adicionar as categorias
    categories.forEach(category => {
      const option = document.createElement('option');
      option.value = category;
      option.textContent = category;
      selectElement.appendChild(option);
    });
    
  } catch (error) {
    console.error('Erro ao carregar categorias:', error);
    showReportError('Erro ao carregar categorias');
  }
}

// Função para carregar produtos
async function loadProducts() {
  try {
    const token = getToken();
    
    const response = await fetch(`${API_URL}/products`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    if (!response.ok) {
      throw new Error('Erro ao carregar produtos');
    }
    
    const data = await response.json();
    
    const selectElement = document.getElementById('movementProduct');
    
    // Manter a opção "Todos os produtos"
    selectElement.innerHTML = '<option value="">Todos os produtos</option>';
    
    // Adicionar os produtos
    data.products.forEach(product => {
      const option = document.createElement('option');
      option.value = product._id;
      option.textContent = product.nome;
      selectElement.appendChild(option);
    });
    
  } catch (error) {
    console.error('Erro ao carregar produtos:', error);
    showReportError('Erro ao carregar produtos');
  }
}

// Função para gerar relatório de estoque
function generateStockReport() {
  try {
    const token = getToken();
    
    // Obter parâmetros do formulário
    const categoria = document.getElementById('stockCategory').value;
    const lowStock = document.getElementById('stockLowStock').value;
    const sortBy = document.getElementById('stockSortBy').value;
    const sortOrder = document.getElementById('stockSortOrder').value;
    const format = document.querySelector('input[name="stockFormat"]:checked').value;
    
    // Construir URL
    let url = `${API_URL}/reports/stock?format=${format}`;
    
    if (categoria) {
      url += `&categoria=${encodeURIComponent(categoria)}`;
    }
    
    if (lowStock) {
      url += `&lowStock=${lowStock}`;
    }
    
    if (sortBy) {
      url += `&sortBy=${sortBy}&sortOrder=${sortOrder}`;
    }
    
    // Abrir URL em nova aba para download
    window.open(url + `&token=${token}`, '_blank');
    
    showReportSuccess('Relatório de estoque gerado com sucesso');
    
  } catch (error) {
    console.error('Erro ao gerar relatório de estoque:', error);
    showReportError('Erro ao gerar relatório de estoque');
  }
}

// Função para gerar relatório de movimentações
function generateMovementsReport() {
  try {
    const token = getToken();
    
    // Obter parâmetros do formulário
    const produto = document.getElementById('movementProduct').value;
    const tipo = document.getElementById('movementType').value;
    const dataInicio = document.getElementById('movementDateStart').value;
    const dataFim = document.getElementById('movementDateEnd').value;
    const format = document.querySelector('input[name="movementFormat"]:checked').value;
    
    // Construir URL
    let url = `${API_URL}/reports/movements?format=${format}`;
    
    if (produto) {
      url += `&produto=${produto}`;
    }
    
    if (tipo) {
      url += `&tipo=${tipo}`;
    }
    
    if (dataInicio) {
      url += `&dataInicio=${dataInicio}`;
    }
    
    if (dataFim) {
      url += `&dataFim=${dataFim}`;
    }
    
    // Abrir URL em nova aba para download
    window.open(url + `&token=${token}`, '_blank');
    
    showReportSuccess('Relatório de movimentações gerado com sucesso');
    
  } catch (error) {
    console.error('Erro ao gerar relatório de movimentações:', error);
    showReportError('Erro ao gerar relatório de movimentações');
  }
}

// Função para gerar relatório de vencimentos
function generateExpiryReport() {
  try {
    const token = getToken();
    
    // Obter parâmetros do formulário
    const days = document.getElementById('expiryDays').value;
    const format = document.querySelector('input[name="expiryFormat"]:checked').value;
    
    // Construir URL
    let url = `${API_URL}/reports/expiry?format=${format}`;
    
    if (days) {
      url += `&days=${days}`;
    }
    
    // Abrir URL em nova aba para download
    window.open(url + `&token=${token}`, '_blank');
    
    showReportSuccess('Relatório de vencimentos gerado com sucesso');
    
  } catch (error) {
    console.error('Erro ao gerar relatório de vencimentos:', error);
    showReportError('Erro ao gerar relatório de vencimentos');
  }
}

// Função para exibir mensagem de sucesso
function showReportSuccess(message) {
  const successElement = document.getElementById('reportSuccess');
  const errorElement = document.getElementById('reportError');
  
  errorElement.classList.add('d-none');
  successElement.textContent = message;
  successElement.classList.remove('d-none');
  
  // Esconder mensagem após 3 segundos
  setTimeout(() => {
    successElement.classList.add('d-none');
  }, 3000);
}

// Função para exibir mensagem de erro
function showReportError(message) {
  const successElement = document.getElementById('reportSuccess');
  const errorElement = document.getElementById('reportError');
  
  successElement.classList.add('d-none');
  errorElement.textContent = message;
  errorElement.classList.remove('d-none');
}
