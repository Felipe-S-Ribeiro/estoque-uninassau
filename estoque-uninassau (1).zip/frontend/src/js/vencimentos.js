// Funções para gerenciamento de vencimentos
document.addEventListener('DOMContentLoaded', function() {
  // Verificar autenticação
  if (!checkAuth()) {
    return;
  }
  
  // Carregar dados do usuário
  const user = getCurrentUser();
  if (user) {
    document.getElementById('userName').textContent = user.nome;
  }
  
  // Configurar evento de logout
  document.getElementById('btnLogout').addEventListener('click', function(e) {
    e.preventDefault();
    logout();
  });
  
  document.getElementById('menuLogout').addEventListener('click', function(e) {
    e.preventDefault();
    logout();
  });
  
  // Carregar produtos vencidos e a vencer
  loadExpiryProducts();
  
  // Configurar evento de filtro
  document.getElementById('btnFilter').addEventListener('click', function() {
    loadExpiryProducts();
  });
  
  // Configurar evento de gerar relatório
  document.getElementById('btnExpiryReport').addEventListener('click', function() {
    generateExpiryReport();
  });
  
  // Configurar eventos dos botões do modal de detalhes
  document.getElementById('btnEditProduct').addEventListener('click', function() {
    const productId = this.getAttribute('data-id');
    window.location.href = `produtos.html?edit=${productId}`;
  });
  
  document.getElementById('btnRegisterMovement').addEventListener('click', function() {
    const productId = this.getAttribute('data-id');
    const productName = this.getAttribute('data-name');
    window.location.href = `produtos.html?movement=${productId}&name=${encodeURIComponent(productName)}`;
  });
});

// Função para carregar produtos vencidos e a vencer
async function loadExpiryProducts() {
  try {
    const token = getToken();
    const days = document.getElementById('filterDays').value;
    
    const response = await fetch(`${API_URL}/products/expiry?days=${days}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    if (!response.ok) {
      throw new Error('Erro ao carregar produtos');
    }
    
    const data = await response.json();
    
    // Atualizar tabelas
    updateExpiredProductsTable(data.expired);
    updateNearExpiryProductsTable(data.nearExpiry);
    
  } catch (error) {
    console.error('Erro ao carregar produtos:', error);
    showExpiryError('Erro ao carregar produtos');
  }
}

// Função para atualizar tabela de produtos vencidos
function updateExpiredProductsTable(products) {
  const tableBody = document.getElementById('expiredProductsTable');
  const noProductsDiv = document.getElementById('noExpiredProducts');
  
  if (!products || products.length === 0) {
    tableBody.innerHTML = '';
    noProductsDiv.classList.remove('d-none');
    return;
  }
  
  noProductsDiv.classList.add('d-none');
  
  let html = '';
  
  products.forEach(product => {
    const expiryDate = new Date(product.dataValidade);
    const today = new Date();
    const diffTime = today - expiryDate;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    html += `
      <tr>
        <td>${product.codigo || '-'}</td>
        <td>${product.nome}</td>
        <td>${product.categoria}</td>
        <td>${product.quantidade}</td>
        <td>${formatDate(product.dataValidade)}</td>
        <td><span class="badge bg-danger">${diffDays} dias</span></td>
        <td>
          <div class="btn-group btn-group-sm">
            <button type="button" class="btn btn-outline-primary" onclick="viewProductDetails('${product._id}')">
              <i class="fas fa-eye"></i>
            </button>
            <button type="button" class="btn btn-outline-success" onclick="openMovementModal('${product._id}', '${product.nome}')">
              <i class="fas fa-exchange-alt"></i>
            </button>
            <button type="button" class="btn btn-outline-secondary" onclick="editProduct('${product._id}')">
              <i class="fas fa-edit"></i>
            </button>
          </div>
        </td>
      </tr>
    `;
  });
  
  tableBody.innerHTML = html;
}

// Função para atualizar tabela de produtos a vencer
function updateNearExpiryProductsTable(products) {
  const tableBody = document.getElementById('nearExpiryProductsTable');
  const noProductsDiv = document.getElementById('noNearExpiryProducts');
  
  if (!products || products.length === 0) {
    tableBody.innerHTML = '';
    noProductsDiv.classList.remove('d-none');
    return;
  }
  
  noProductsDiv.classList.add('d-none');
  
  let html = '';
  
  products.forEach(product => {
    const expiryDate = new Date(product.dataValidade);
    const today = new Date();
    const diffTime = expiryDate - today;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    let badgeClass = 'bg-warning';
    if (diffDays <= 7) {
      badgeClass = 'bg-danger';
    } else if (diffDays <= 15) {
      badgeClass = 'bg-warning';
    } else {
      badgeClass = 'bg-info';
    }
    
    html += `
      <tr>
        <td>${product.codigo || '-'}</td>
        <td>${product.nome}</td>
        <td>${product.categoria}</td>
        <td>${product.quantidade}</td>
        <td>${formatDate(product.dataValidade)}</td>
        <td><span class="badge ${badgeClass}">${diffDays} dias</span></td>
        <td>
          <div class="btn-group btn-group-sm">
            <button type="button" class="btn btn-outline-primary" onclick="viewProductDetails('${product._id}')">
              <i class="fas fa-eye"></i>
            </button>
            <button type="button" class="btn btn-outline-success" onclick="openMovementModal('${product._id}', '${product.nome}')">
              <i class="fas fa-exchange-alt"></i>
            </button>
            <button type="button" class="btn btn-outline-secondary" onclick="editProduct('${product._id}')">
              <i class="fas fa-edit"></i>
            </button>
          </div>
        </td>
      </tr>
    `;
  });
  
  tableBody.innerHTML = html;
}

// Função para visualizar detalhes do produto
async function viewProductDetails(productId) {
  try {
    const token = getToken();
    
    // Carregar dados do produto
    const response = await fetch(`${API_URL}/products/${productId}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    if (!response.ok) {
      throw new Error('Erro ao carregar dados do produto');
    }
    
    const product = await response.json();
    
    // Preencher detalhes do produto
    document.getElementById('detailName').textContent = product.nome;
    document.getElementById('detailCode').textContent = product.codigo || '-';
    document.getElementById('detailCategory').textContent = product.categoria;
    document.getElementById('detailSupplier').textContent = product.fornecedor || '-';
    document.getElementById('detailQuantity').textContent = product.quantidade;
    document.getElementById('detailMinStock').textContent = product.estoqueMinimo;
    document.getElementById('detailCostPrice').textContent = `R$ ${product.precoCusto.toFixed(2)}`;
    document.getElementById('detailSellPrice').textContent = `R$ ${product.precoVenda.toFixed(2)}`;
    
    document.getElementById('detailManufactureDate').textContent = product.dataFabricacao ? formatDate(product.dataFabricacao) : '-';
    document.getElementById('detailExpiryDate').textContent = product.dataValidade ? formatDate(product.dataValidade) : '-';
    document.getElementById('detailCreatedAt').textContent = formatDate(product.createdAt);
    document.getElementById('detailUpdatedAt').textContent = formatDate(product.updatedAt);
    
    document.getElementById('detailLocation').textContent = product.localizacao || '-';
    document.getElementById('detailDescription').textContent = product.descricao || '-';
    
    // Configurar botões de ação
    document.getElementById('btnEditProduct').setAttribute('data-id', product._id);
    document.getElementById('btnRegisterMovement').setAttribute('data-id', product._id);
    document.getElementById('btnRegisterMovement').setAttribute('data-name', product.nome);
    
    // Abrir modal
    const modal = new bootstrap.Modal(document.getElementById('detailsModal'));
    modal.show();
    
  } catch (error) {
    console.error('Erro ao visualizar detalhes do produto:', error);
    showExpiryError('Erro ao carregar detalhes do produto');
  }
}

// Função para editar produto
function editProduct(productId) {
  window.location.href = `produtos.html?edit=${productId}`;
}

// Função para abrir modal de movimentação
function openMovementModal(productId, productName) {
  window.location.href = `produtos.html?movement=${productId}&name=${encodeURIComponent(productName)}`;
}

// Função para gerar relatório de vencimentos
function generateExpiryReport() {
  try {
    const token = getToken();
    const days = document.getElementById('filterDays').value;
    
    // Construir URL
    let url = `${API_URL}/reports/expiry?format=pdf&days=${days}&token=${token}`;
    
    // Abrir URL em nova aba para download
    window.open(url, '_blank');
    
    showExpirySuccess('Relatório de vencimentos gerado com sucesso');
    
  } catch (error) {
    console.error('Erro ao gerar relatório de vencimentos:', error);
    showExpiryError('Erro ao gerar relatório de vencimentos');
  }
}

// Função para exibir mensagem de sucesso
function showExpirySuccess(message) {
  const successElement = document.getElementById('expirySuccess');
  const errorElement = document.getElementById('expiryError');
  
  errorElement.classList.add('d-none');
  successElement.textContent = message;
  successElement.classList.remove('d-none');
  
  // Esconder mensagem após 3 segundos
  setTimeout(() => {
    successElement.classList.add('d-none');
  }, 3000);
}

// Função para exibir mensagem de erro
function showExpiryError(message) {
  const successElement = document.getElementById('expirySuccess');
  const errorElement = document.getElementById('expiryError');
  
  successElement.classList.add('d-none');
  errorElement.textContent = message;
  errorElement.classList.remove('d-none');
}

// Função auxiliar para formatar data
function formatDate(dateString) {
  const date = new Date(dateString);
  return date.toLocaleDateString('pt-BR');
}
