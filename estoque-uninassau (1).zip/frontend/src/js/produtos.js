// Funções para gerenciamento de produtos
document.addEventListener('DOMContentLoaded', function() {
  // Verificar autenticação
  if (!checkAuth()) {
    return;
  }
  
  // Carregar dados do usuário
  const user = getCurrentUser();
  if (user) {
    document.getElementById('userName').textContent = user.nome;
  }
  
  // Configurar evento de logout
  document.getElementById('btnLogout').addEventListener('click', function(e) {
    e.preventDefault();
    logout();
  });
  
  document.getElementById('menuLogout').addEventListener('click', function(e) {
    e.preventDefault();
    logout();
  });
  
  // Carregar categorias para o filtro
  loadCategories();
  
  // Carregar produtos
  loadProducts();
  
  // Configurar eventos de busca
  document.getElementById('btnSearch').addEventListener('click', function() {
    loadProducts(1);
  });
  
  document.getElementById('searchProduct').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
      loadProducts(1);
    }
  });
  
  document.getElementById('filterCategory').addEventListener('change', function() {
    loadProducts(1);
  });
  
  // Configurar evento de salvar produto
  document.getElementById('btnSaveProduct').addEventListener('click', saveProduct);
  
  // Configurar evento de salvar movimentação
  document.getElementById('btnSaveMovement').addEventListener('click', saveMovement);
  
  // Resetar formulário quando o modal for fechado
  document.getElementById('productModal').addEventListener('hidden.bs.modal', function() {
    document.getElementById('productForm').reset();
    document.getElementById('productId').value = '';
    document.getElementById('productModalLabel').textContent = 'Novo Produto';
  });
  
  document.getElementById('movementModal').addEventListener('hidden.bs.modal', function() {
    document.getElementById('movementForm').reset();
    document.getElementById('movementProductId').value = '';
  });
});

// Função para carregar categorias
async function loadCategories() {
  try {
    const token = getToken();
    
    const response = await fetch(`${API_URL}/products/categories`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    if (!response.ok) {
      throw new Error('Erro ao carregar categorias');
    }
    
    const categories = await response.json();
    
    const selectElement = document.getElementById('filterCategory');
    
    // Manter a opção "Todas as categorias"
    selectElement.innerHTML = '<option value="">Todas as categorias</option>';
    
    // Adicionar as categorias
    categories.forEach(category => {
      const option = document.createElement('option');
      option.value = category;
      option.textContent = category;
      selectElement.appendChild(option);
    });
    
  } catch (error) {
    console.error('Erro ao carregar categorias:', error);
    showProductError('Erro ao carregar categorias');
  }
}

// Função para carregar produtos
async function loadProducts(page = 1) {
  try {
    const token = getToken();
    const keyword = document.getElementById('searchProduct').value;
    const categoria = document.getElementById('filterCategory').value;
    
    let url = `${API_URL}/products?page=${page}`;
    
    if (keyword) {
      url += `&keyword=${encodeURIComponent(keyword)}`;
    }
    
    if (categoria) {
      url += `&categoria=${encodeURIComponent(categoria)}`;
    }
    
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    if (!response.ok) {
      throw new Error('Erro ao carregar produtos');
    }
    
    const data = await response.json();
    
    updateProductsTable(data.products);
    updatePagination(data.page, data.pages);
    
  } catch (error) {
    console.error('Erro ao carregar produtos:', error);
    showProductError('Erro ao carregar produtos');
  }
}

// Função para atualizar tabela de produtos
function updateProductsTable(products) {
  const tableBody = document.getElementById('productsTable');
  
  if (!products || products.length === 0) {
    tableBody.innerHTML = '<tr><td colspan="7" class="text-center">Nenhum produto encontrado</td></tr>';
    return;
  }
  
  let html = '';
  
  products.forEach(product => {
    // Determinar status do produto
    let statusBadge = '';
    
    if (product.quantidade <= 0) {
      statusBadge = '<span class="badge bg-danger">Sem estoque</span>';
    } else if (product.quantidade <= product.estoqueMinimo) {
      statusBadge = '<span class="badge bg-warning">Estoque baixo</span>';
    } else {
      statusBadge = '<span class="badge bg-success">OK</span>';
    }
    
    // Verificar validade
    if (product.dataValidade) {
      const today = new Date();
      const expiryDate = new Date(product.dataValidade);
      
      if (expiryDate < today) {
        statusBadge += ' <span class="badge bg-danger">Vencido</span>';
      } else {
        const diffTime = expiryDate - today;
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        
        if (diffDays <= 30) {
          statusBadge += ` <span class="badge bg-warning">Vence em ${diffDays} dias</span>`;
        }
      }
    }
    
    html += `
      <tr>
        <td>${product.codigo || '-'}</td>
        <td>${product.nome}</td>
        <td>${product.categoria}</td>
        <td>${product.quantidade}</td>
        <td>R$ ${product.precoVenda.toFixed(2)}</td>
        <td>${statusBadge}</td>
        <td>
          <div class="btn-group btn-group-sm">
            <button type="button" class="btn btn-outline-primary" onclick="viewProductDetails('${product._id}')">
              <i class="fas fa-eye"></i>
            </button>
            <button type="button" class="btn btn-outline-success" onclick="openMovementModal('${product._id}', '${product.nome}')">
              <i class="fas fa-exchange-alt"></i>
            </button>
            <button type="button" class="btn btn-outline-secondary" onclick="editProduct('${product._id}')">
              <i class="fas fa-edit"></i>
            </button>
            <button type="button" class="btn btn-outline-danger" onclick="deleteProduct('${product._id}')">
              <i class="fas fa-trash"></i>
            </button>
          </div>
        </td>
      </tr>
    `;
  });
  
  tableBody.innerHTML = html;
}

// Função para atualizar paginação
function updatePagination(currentPage, totalPages) {
  const pagination = document.getElementById('pagination');
  
  if (totalPages <= 1) {
    pagination.innerHTML = '';
    return;
  }
  
  let html = '';
  
  // Botão anterior
  html += `
    <li class="page-item ${currentPage === 1 ? 'disabled' : ''}">
      <a class="page-link" href="#" onclick="loadProducts(${currentPage - 1}); return false;">Anterior</a>
    </li>
  `;
  
  // Páginas
  for (let i = 1; i <= totalPages; i++) {
    html += `
      <li class="page-item ${i === currentPage ? 'active' : ''}">
        <a class="page-link" href="#" onclick="loadProducts(${i}); return false;">${i}</a>
      </li>
    `;
  }
  
  // Botão próximo
  html += `
    <li class="page-item ${currentPage === totalPages ? 'disabled' : ''}">
      <a class="page-link" href="#" onclick="loadProducts(${currentPage + 1}); return false;">Próximo</a>
    </li>
  `;
  
  pagination.innerHTML = html;
}

// Função para salvar produto (novo ou edição)
async function saveProduct() {
  try {
    const productId = document.getElementById('productId').value;
    const isEdit = !!productId;
    
    // Obter dados do formulário
    const productData = {
      nome: document.getElementById('productName').value,
      codigo: document.getElementById('productCode').value,
      categoria: document.getElementById('productCategory').value,
      fornecedor: document.getElementById('productSupplier').value,
      precoCusto: parseFloat(document.getElementById('productCostPrice').value),
      precoVenda: parseFloat(document.getElementById('productSellPrice').value),
      quantidade: parseInt(document.getElementById('productQuantity').value),
      estoqueMinimo: parseInt(document.getElementById('productMinStock').value),
      dataFabricacao: document.getElementById('productManufactureDate').value || null,
      dataValidade: document.getElementById('productExpiryDate').value || null,
      localizacao: document.getElementById('productLocation').value,
      descricao: document.getElementById('productDescription').value
    };
    
    // Validar campos obrigatórios
    if (!productData.nome || !productData.categoria || !productData.precoCusto || !productData.precoVenda) {
      showProductError('Preencha todos os campos obrigatórios');
      return;
    }
    
    const token = getToken();
    
    let url = `${API_URL}/products`;
    let method = 'POST';
    
    if (isEdit) {
      url = `${API_URL}/products/${productId}`;
      method = 'PUT';
    }
    
    const response = await fetch(url, {
      method: method,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(productData)
    });
    
    if (!response.ok) {
      const data = await response.json();
      throw new Error(data.message || 'Erro ao salvar produto');
    }
    
    // Fechar modal e recarregar produtos
    const modal = bootstrap.Modal.getInstance(document.getElementById('productModal'));
    modal.hide();
    
    showProductSuccess(isEdit ? 'Produto atualizado com sucesso' : 'Produto cadastrado com sucesso');
    
    // Recarregar produtos e categorias
    loadProducts();
    loadCategories();
    
  } catch (error) {
    console.error('Erro ao salvar produto:', error);
    showProductError(error.message);
  }
}

// Função para editar produto
async function editProduct(productId) {
  try {
    const token = getToken();
    
    const response = await fetch(`${API_URL}/products/${productId}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    if (!response.ok) {
      throw new Error('Erro ao carregar dados do produto');
    }
    
    const product = await response.json();
    
    // Preencher formulário
    document.getElementById('productId').value = product._id;
    document.getElementById('productName').value = product.nome;
    document.getElementById('productCode').value = product.codigo || '';
    document.getElementById('productCategory').value = product.categoria;
    document.getElementById('productSupplier').value = product.fornecedor || '';
    document.getElementById('productCostPrice').value = product.precoCusto;
    document.getElementById('productSellPrice').value = product.precoVenda;
    document.getElementById('productMinStock').value = product.estoqueMinimo;
    document.getElementById('productQuantity').value = product.quantidade;
    
    if (product.dataFabricacao) {
      document.getElementById('productManufactureDate').value = product.dataFabricacao.split('T')[0];
    }
    
    if (product.dataValidade) {
      document.getElementById('productExpiryDate').value = product.dataValidade.split('T')[0];
    }
    
    document.getElementById('productLocation').value = product.localizacao || '';
    document.getElementById('productDescription').value = product.descricao || '';
    
    // Atualizar título do modal
    document.getElementById('productModalLabel').textContent = 'Editar Produto';
    
    // Abrir modal
    const modal = new bootstrap.Modal(document.getElementById('productModal'));
    modal.show();
    
  } catch (error) {
    console.error('Erro ao editar produto:', error);
    showProductError(error.message);
  }
}

// Função para excluir produto
async function deleteProduct(productId) {
  if (!confirm('Tem certeza que deseja excluir este produto?')) {
    return;
  }
  
  try {
    const token = getToken();
    
    const response = await fetch(`${API_URL}/products/${productId}`, {
      method: 'DELETE',
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    if (!response.ok) {
      const data = await response.json();
      throw new Error(data.message || 'Erro ao excluir produto');
    }
    
    showProductSuccess('Produto excluído com sucesso');
    
    // Recarregar produtos
    loadProducts();
    
  } catch (error) {
    console.error('Erro ao excluir produto:', error);
    showProductError(error.message);
  }
}

// Função para abrir modal de movimentação
function openMovementModal(productId, productName) {
  document.getElementById('movementProductId').value = productId;
  document.getElementById('movementProductName').value = productName;
  
  const modal = new bootstrap.Modal(document.getElementById('movementModal'));
  modal.show();
}

// Função para salvar movimentação
async function saveMovement() {
  try {
    const productId = document.getElementById('movementProductId').value;
    const tipo = document.getElementById('movementType').value;
    const quantidade = parseInt(document.getElementById('movementQuantity').value);
    const motivo = document.getElementById('movementReason').value;
    const observacao = document.getElementById('movementObservation').value;
    
    // Validar campos obrigatórios
    if (!productId || !tipo || !quantidade || !motivo) {
      showProductError('Preencha todos os campos obrigatórios');
      return;
    }
    
    // Validar quantidade
    if (quantidade <= 0) {
      showProductError('A quantidade deve ser maior que zero');
      return;
    }
    
    const token = getToken();
    
    const response = await fetch(`${API_URL}/stock`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({
        produto: productId,
        tipo,
        quantidade,
        motivo,
        observacao
      })
    });
    
    if (!response.ok) {
      const data = await response.json();
      throw new Error(data.message || 'Erro ao registrar movimentação');
    }
    
    // Fechar modal e recarregar produtos
    const modal = bootstrap.Modal.getInstance(document.getElementById('movementModal'));
    modal.hide();
    
    showProductSuccess('Movimentação registrada com sucesso');
    
    // Recarregar produtos
    loadProducts();
    
  } catch (error) {
    console.error('Erro ao registrar movimentação:', error);
    showProductError(error.message);
  }
}

// Função para visualizar detalhes do produto
async function viewProductDetails(productId) {
  try {
    const token = getToken();
    
    // Carregar dados do produto
    const productResponse = await fetch(`${API_URL}/products/${productId}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    if (!productResponse.ok) {
      throw new Error('Erro ao carregar dados do produto');
    }
    
    const product = await productResponse.json();
    
    // Preencher detalhes do produto
    document.getElementById('detailName').textContent = product.nome;
    document.getElementById('detailCode').textContent = product.codigo || '-';
    document.getElementById('detailCategory').textContent = product.categoria;
    document.getElementById('detailSupplier').textContent = product.fornecedor || '-';
    document.getElementById('detailQuantity').textContent = product.quantidade;
    document.getElementById('detailMinStock').textContent = product.estoqueMinimo;
    document.getElementById('detailCostPrice').textContent = `R$ ${product.precoCusto.toFixed(2)}`;
    document.getElementById('detailSellPrice').textContent = `R$ ${product.precoVenda.toFixed(2)}`;
    
    document.getElementById('detailManufactureDate').textContent = product.dataFabricacao ? formatDate(product.dataFabricacao) : '-';
    document.getElementById('detailExpiryDate').textContent = product.dataValidade ? formatDate(product.dataValidade) : '-';
    document.getElementById('detailCreatedAt').textContent = formatDate(product.createdAt);
    document.getElementById('detailUpdatedAt').textContent = formatDate(product.updatedAt);
    
    document.getElementById('detailLocation').textContent = product.localizacao || '-';
    document.getElementById('detailDescription').textContent = product.descricao || '-';
    
    // Carregar movimentações do produto
    const movementsResponse = await fetch(`${API_URL}/stock/product/${productId}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    if (!movementsResponse.ok) {
      throw new Error('Erro ao carregar movimentações do produto');
    }
    
    const movements = await movementsResponse.json();
    
    // Atualizar tabela de movimentações
    updateMovementsTable(movements);
    
    // Abrir modal
    const modal = new bootstrap.Modal(document.getElementById('detailsModal'));
    modal.show();
    
  } catch (error) {
    console.error('Erro ao visualizar detalhes do produto:', error);
    showProductError(error.message);
  }
}

// Função para atualizar tabela de movimentações
function updateMovementsTable(movements) {
  const tableBody = document.getElementById('detailMovements');
  
  if (!movements || movements.length === 0) {
    tableBody.innerHTML = '<tr><td colspan="5" class="text-center">Nenhuma movimentação encontrada</td></tr>';
    return;
  }
  
  let html = '';
  
  movements.forEach(movement => {
    const tipoClass = movement.tipo === 'entrada' ? 'bg-success' : movement.tipo === 'saida' ? 'bg-danger' : 'bg-warning';
    const tipoText = movement.tipo === 'entrada' ? 'Entrada' : movement.tipo === 'saida' ? 'Saída' : 'Ajuste';
    
    html += `
      <tr>
        <td>${formatDate(movement.data)}</td>
        <td><span class="badge ${tipoClass}">${tipoText}</span></td>
        <td>${movement.quantidade}</td>
        <td>${movement.responsavel ? movement.responsavel.nome : '-'}</td>
        <td>${movement.motivo}</td>
      </tr>
    `;
  });
  
  tableBody.innerHTML = html;
}

// Função para exibir mensagem de sucesso
function showProductSuccess(message) {
  const successElement = document.getElementById('productSuccess');
  const errorElement = document.getElementById('productError');
  
  errorElement.classList.add('d-none');
  successElement.textContent = message;
  successElement.classList.remove('d-none');
  
  // Esconder mensagem após 3 segundos
  setTimeout(() => {
    successElement.classList.add('d-none');
  }, 3000);
}

// Função para exibir mensagem de erro
function showProductError(message) {
  const successElement = document.getElementById('productSuccess');
  const errorElement = document.getElementById('productError');
  
  successElement.classList.add('d-none');
  errorElement.textContent = message;
  errorElement.classList.remove('d-none');
}

// Função auxiliar para formatar data
function formatDate(dateString) {
  const date = new Date(dateString);
  return date.toLocaleDateString('pt-BR') + ' ' + date.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
}
