const jwt = require('jsonwebtoken');
const User = require('../models/userModel');

// Gerar token JWT
const generateToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET || 'estoque_uninassau_secret', {
    expiresIn: '30d'
  });
};

// @desc    Registrar um novo usuário
// @route   POST /api/users/register
// @access  Public
const registerUser = async (req, res) => {
  try {
    const { nome, email, senha, cargo, departamento } = req.body;

    // Verificar se o usuário já existe
    const userExists = await User.findOne({ email });

    if (userExists) {
      return res.status(400).json({ message: 'Usuário já existe' });
    }

    // Criar novo usuário
    const user = await User.create({
      nome,
      email,
      senha,
      cargo,
      departamento,
      // O primeiro usuário registrado será admin
      role: (await User.countDocuments({})) === 0 ? 'admin' : 'user'
    });

    if (user) {
      res.status(201).json({
        _id: user._id,
        nome: user.nome,
        email: user.email,
        cargo: user.cargo,
        departamento: user.departamento,
        role: user.role,
        token: generateToken(user._id)
      });
    } else {
      res.status(400).json({ message: 'Dados de usuário inválidos' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Autenticar usuário e gerar token
// @route   POST /api/users/login
// @access  Public
const loginUser = async (req, res) => {
  try {
    const { email, senha } = req.body;

    // Verificar se o usuário existe
    const user = await User.findOne({ email });

    if (user && (await user.matchPassword(senha))) {
      // Atualizar último acesso
      user.ultimoAcesso = Date.now();
      await user.save();

      res.json({
        _id: user._id,
        nome: user.nome,
        email: user.email,
        cargo: user.cargo,
        departamento: user.departamento,
        role: user.role,
        token: generateToken(user._id)
      });
    } else {
      res.status(401).json({ message: 'Email ou senha inválidos' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Obter perfil do usuário
// @route   GET /api/users/profile
// @access  Private
const getUserProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user._id).select('-senha');
    
    if (user) {
      res.json(user);
    } else {
      res.status(404).json({ message: 'Usuário não encontrado' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Atualizar perfil do usuário
// @route   PUT /api/users/profile
// @access  Private
const updateUserProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    
    if (user) {
      user.nome = req.body.nome || user.nome;
      user.email = req.body.email || user.email;
      user.cargo = req.body.cargo || user.cargo;
      user.departamento = req.body.departamento || user.departamento;
      
      if (req.body.senha) {
        user.senha = req.body.senha;
      }
      
      const updatedUser = await user.save();
      
      res.json({
        _id: updatedUser._id,
        nome: updatedUser.nome,
        email: updatedUser.email,
        cargo: updatedUser.cargo,
        departamento: updatedUser.departamento,
        role: updatedUser.role,
        token: generateToken(updatedUser._id)
      });
    } else {
      res.status(404).json({ message: 'Usuário não encontrado' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Obter todos os usuários
// @route   GET /api/users
// @access  Private/Admin
const getUsers = async (req, res) => {
  try {
    const users = await User.find({}).select('-senha');
    res.json(users);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  registerUser,
  loginUser,
  getUserProfile,
  updateUserProfile,
  getUsers
};
