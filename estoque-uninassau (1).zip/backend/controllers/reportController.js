const Product = require('../models/productModel');
const StockMovement = require('../models/stockMovementModel');
const PDFDocument = require('pdfkit');
const fs = require('fs');
const path = require('path');

// @desc    Gerar relatório de produtos em estoque
// @route   GET /api/reports/stock
// @access  Private
const generateStockReport = async (req, res) => {
  try {
    // Filtros
    const filters = {};
    
    if (req.query.categoria) {
      filters.categoria = req.query.categoria;
    }
    
    if (req.query.lowStock === 'true') {
      filters.$expr = { $lte: ["$quantidade", "$estoqueMinimo"] };
    }
    
    // Ordenação
    const sort = {};
    if (req.query.sortBy) {
      sort[req.query.sortBy] = req.query.sortOrder === 'desc' ? -1 : 1;
    } else {
      sort.nome = 1; // Ordenação padrão por nome
    }
    
    // Buscar produtos
    const products = await Product.find(filters).sort(sort);
    
    // Formato do relatório
    const format = req.query.format || 'json';
    
    if (format === 'json') {
      // Retornar como JSON
      return res.json({
        totalProducts: products.length,
        totalItems: products.reduce((acc, product) => acc + product.quantidade, 0),
        totalValue: products.reduce((acc, product) => acc + (product.quantidade * product.precoVenda), 0),
        products
      });
    } else if (format === 'pdf') {
      // Gerar PDF
      const reportPath = path.join(__dirname, '../temp', `stock_report_${Date.now()}.pdf`);
      
      await generateStockPDF(products, reportPath);
      
      // Enviar o arquivo
      res.download(reportPath, 'relatorio_estoque.pdf', (err) => {
        if (err) {
          console.error('Erro ao enviar arquivo:', err);
        }
        
        // Remover o arquivo temporário após o envio
        fs.unlink(reportPath, (unlinkErr) => {
          if (unlinkErr) {
            console.error('Erro ao remover arquivo temporário:', unlinkErr);
          }
        });
      });
    } else if (format === 'csv') {
      // Gerar CSV
      let csv = 'Código,Nome,Categoria,Quantidade,Estoque Mínimo,Preço Custo,Preço Venda,Validade\n';
      
      products.forEach(product => {
        csv += `"${product.codigo || ''}","${product.nome}","${product.categoria}",${product.quantidade},${product.estoqueMinimo},${product.precoCusto},${product.precoVenda},"${product.dataValidade ? new Date(product.dataValidade).toLocaleDateString('pt-BR') : ''}"\n`;
      });
      
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename=relatorio_estoque.csv');
      res.send(csv);
    } else {
      return res.status(400).json({ message: 'Formato de relatório inválido' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Gerar relatório de movimentações
// @route   GET /api/reports/movements
// @access  Private
const generateMovementsReport = async (req, res) => {
  try {
    // Filtros
    const filters = {};
    
    if (req.query.produto) {
      filters.produto = req.query.produto;
    }
    
    if (req.query.tipo) {
      filters.tipo = req.query.tipo;
    }
    
    if (req.query.responsavel) {
      filters.responsavel = req.query.responsavel;
    }
    
    // Filtro por data
    if (req.query.dataInicio || req.query.dataFim) {
      filters.data = {};
      
      if (req.query.dataInicio) {
        filters.data.$gte = new Date(req.query.dataInicio);
      }
      
      if (req.query.dataFim) {
        filters.data.$lte = new Date(req.query.dataFim);
        // Ajustar para o final do dia
        filters.data.$lte.setHours(23, 59, 59, 999);
      }
    }
    
    // Buscar movimentações
    const movements = await StockMovement.find(filters)
      .populate('produto', 'nome codigo')
      .populate('responsavel', 'nome')
      .sort({ data: -1 });
    
    // Formato do relatório
    const format = req.query.format || 'json';
    
    if (format === 'json') {
      // Retornar como JSON
      return res.json({
        totalMovements: movements.length,
        totalEntries: movements.filter(m => m.tipo === 'entrada').length,
        totalExits: movements.filter(m => m.tipo === 'saida').length,
        totalAdjustments: movements.filter(m => m.tipo === 'ajuste').length,
        movements
      });
    } else if (format === 'pdf') {
      // Gerar PDF
      const reportPath = path.join(__dirname, '../temp', `movements_report_${Date.now()}.pdf`);
      
      await generateMovementsPDF(movements, reportPath);
      
      // Enviar o arquivo
      res.download(reportPath, 'relatorio_movimentacoes.pdf', (err) => {
        if (err) {
          console.error('Erro ao enviar arquivo:', err);
        }
        
        // Remover o arquivo temporário após o envio
        fs.unlink(reportPath, (unlinkErr) => {
          if (unlinkErr) {
            console.error('Erro ao remover arquivo temporário:', unlinkErr);
          }
        });
      });
    } else if (format === 'csv') {
      // Gerar CSV
      let csv = 'Data,Produto,Tipo,Quantidade,Responsável,Motivo\n';
      
      movements.forEach(movement => {
        const date = new Date(movement.data).toLocaleString('pt-BR');
        const productName = movement.produto ? movement.produto.nome : 'N/A';
        const tipo = movement.tipo === 'entrada' ? 'Entrada' : movement.tipo === 'saida' ? 'Saída' : 'Ajuste';
        const responsavel = movement.responsavel ? movement.responsavel.nome : 'N/A';
        
        csv += `"${date}","${productName}","${tipo}",${movement.quantidade},"${responsavel}","${movement.motivo || ''}"\n`;
      });
      
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename=relatorio_movimentacoes.csv');
      res.send(csv);
    } else {
      return res.status(400).json({ message: 'Formato de relatório inválido' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Gerar relatório de produtos vencidos ou a vencer
// @route   GET /api/reports/expiry
// @access  Private
const generateExpiryReport = async (req, res) => {
  try {
    const today = new Date();
    
    // Definir período para produtos a vencer (padrão: 30 dias)
    const daysAhead = parseInt(req.query.days) || 30;
    const futureDate = new Date();
    futureDate.setDate(today.getDate() + daysAhead);
    
    // Buscar produtos com data de validade
    const products = await Product.find({
      dataValidade: { $ne: null }
    }).sort({ dataValidade: 1 });
    
    // Separar produtos vencidos e a vencer
    const expired = products.filter(p => new Date(p.dataValidade) < today);
    const nearExpiry = products.filter(p => {
      const expiryDate = new Date(p.dataValidade);
      return expiryDate >= today && expiryDate <= futureDate;
    });
    
    // Formato do relatório
    const format = req.query.format || 'json';
    
    if (format === 'json') {
      // Retornar como JSON
      return res.json({
        totalExpired: expired.length,
        totalNearExpiry: nearExpiry.length,
        expired,
        nearExpiry
      });
    } else if (format === 'pdf') {
      // Gerar PDF
      const reportPath = path.join(__dirname, '../temp', `expiry_report_${Date.now()}.pdf`);
      
      await generateExpiryPDF(expired, nearExpiry, daysAhead, reportPath);
      
      // Enviar o arquivo
      res.download(reportPath, 'relatorio_vencimentos.pdf', (err) => {
        if (err) {
          console.error('Erro ao enviar arquivo:', err);
        }
        
        // Remover o arquivo temporário após o envio
        fs.unlink(reportPath, (unlinkErr) => {
          if (unlinkErr) {
            console.error('Erro ao remover arquivo temporário:', unlinkErr);
          }
        });
      });
    } else if (format === 'csv') {
      // Gerar CSV
      let csv = 'Status,Código,Nome,Categoria,Quantidade,Data de Validade,Dias Restantes\n';
      
      // Produtos vencidos
      expired.forEach(product => {
        const expiryDate = new Date(product.dataValidade);
        const diffTime = today - expiryDate;
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        
        csv += `"Vencido","${product.codigo || ''}","${product.nome}","${product.categoria}",${product.quantidade},"${expiryDate.toLocaleDateString('pt-BR')}","-${diffDays}"\n`;
      });
      
      // Produtos a vencer
      nearExpiry.forEach(product => {
        const expiryDate = new Date(product.dataValidade);
        const diffTime = expiryDate - today;
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        
        csv += `"A vencer","${product.codigo || ''}","${product.nome}","${product.categoria}",${product.quantidade},"${expiryDate.toLocaleDateString('pt-BR')}","${diffDays}"\n`;
      });
      
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename=relatorio_vencimentos.csv');
      res.send(csv);
    } else {
      return res.status(400).json({ message: 'Formato de relatório inválido' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Função auxiliar para gerar PDF de estoque
const generateStockPDF = async (products, filePath) => {
  return new Promise((resolve, reject) => {
    try {
      // Criar diretório temp se não existir
      const dir = path.dirname(filePath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      
      const doc = new PDFDocument({ margin: 50 });
      const stream = fs.createWriteStream(filePath);
      
      doc.pipe(stream);
      
      // Título
      doc.fontSize(20).text('Relatório de Estoque', { align: 'center' });
      doc.moveDown();
      
      // Data do relatório
      doc.fontSize(12).text(`Data: ${new Date().toLocaleDateString('pt-BR')} ${new Date().toLocaleTimeString('pt-BR')}`, { align: 'right' });
      doc.moveDown();
      
      // Resumo
      doc.fontSize(14).text('Resumo', { underline: true });
      doc.fontSize(12).text(`Total de Produtos: ${products.length}`);
      doc.text(`Total de Itens: ${products.reduce((acc, product) => acc + product.quantidade, 0)}`);
      doc.text(`Valor Total: R$ ${products.reduce((acc, product) => acc + (product.quantidade * product.precoVenda), 0).toFixed(2)}`);
      doc.moveDown();
      
      // Tabela de produtos
      doc.fontSize(14).text('Lista de Produtos', { underline: true });
      doc.moveDown();
      
      // Cabeçalho da tabela
      const tableTop = doc.y;
      const tableHeaders = ['Código', 'Nome', 'Categoria', 'Qtd', 'Preço', 'Valor Total'];
      const columnWidths = [70, 150, 100, 50, 70, 100];
      
      let currentY = tableTop;
      
      // Desenhar cabeçalho
      doc.fontSize(10).font('Helvetica-Bold');
      tableHeaders.forEach((header, i) => {
        const x = 50 + columnWidths.slice(0, i).reduce((acc, width) => acc + width, 0);
        doc.text(header, x, currentY);
      });
      
      currentY += 20;
      doc.moveTo(50, currentY).lineTo(550, currentY).stroke();
      currentY += 10;
      
      // Desenhar linhas da tabela
      doc.font('Helvetica');
      products.forEach((product, index) => {
        // Verificar se precisa de nova página
        if (currentY > 700) {
          doc.addPage();
          currentY = 50;
        }
        
        const valorTotal = product.quantidade * product.precoVenda;
        
        doc.text(product.codigo || '-', 50, currentY);
        doc.text(product.nome.substring(0, 25) + (product.nome.length > 25 ? '...' : ''), 50 + columnWidths[0], currentY);
        doc.text(product.categoria, 50 + columnWidths[0] + columnWidths[1], currentY);
        doc.text(product.quantidade.toString(), 50 + columnWidths[0] + columnWidths[1] + columnWidths[2], currentY);
        doc.text(`R$ ${product.precoVenda.toFixed(2)}`, 50 + columnWidths[0] + columnWidths[1] + columnWidths[2] + columnWidths[3], currentY);
        doc.text(`R$ ${valorTotal.toFixed(2)}`, 50 + columnWidths[0] + columnWidths[1] + columnWidths[2] + columnWidths[3] + columnWidths[4], currentY);
        
        currentY += 20;
        
        // Linha divisória entre produtos
        if (index < products.length - 1) {
          doc.moveTo(50, currentY - 10).lineTo(550, currentY - 10).stroke();
        }
      });
      
      // Rodapé
      doc.fontSize(10).text('Estoque Uninassau - Sistema de Controle de Estoque', 50, 750, { align: 'center' });
      
      doc.end();
      
      stream.on('finish', () => {
        resolve();
      });
      
      stream.on('error', (err) => {
        reject(err);
      });
    } catch (error) {
      reject(error);
    }
  });
};

// Função auxiliar para gerar PDF de movimentações
const generateMovementsPDF = async (movements, filePath) => {
  return new Promise((resolve, reject) => {
    try {
      // Criar diretório temp se não existir
      const dir = path.dirname(filePath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      
      const doc = new PDFDocument({ margin: 50 });
      const stream = fs.createWriteStream(filePath);
      
      doc.pipe(stream);
      
      // Título
      doc.fontSize(20).text('Relatório de Movimentações', { align: 'center' });
      doc.moveDown();
      
      // Data do relatório
      doc.fontSize(12).text(`Data: ${new Date().toLocaleDateString('pt-BR')} ${new Date().toLocaleTimeString('pt-BR')}`, { align: 'right' });
      doc.moveDown();
      
      // Resumo
      doc.fontSize(14).text('Resumo', { underline: true });
      doc.fontSize(12).text(`Total de Movimentações: ${movements.length}`);
      doc.text(`Entradas: ${movements.filter(m => m.tipo === 'entrada').length}`);
      doc.text(`Saídas: ${movements.filter(m => m.tipo === 'saida').length}`);
      doc.text(`Ajustes: ${movements.filter(m => m.tipo === 'ajuste').length}`);
      doc.moveDown();
      
      // Tabela de movimentações
      doc.fontSize(14).text('Lista de Movimentações', { underline: true });
      doc.moveDown();
      
      // Cabeçalho da tabela
      const tableTop = doc.y;
      const tableHeaders = ['Data', 'Produto', 'Tipo', 'Qtd', 'Responsável', 'Motivo'];
      const columnWidths = [80, 150, 60, 40, 100, 100];
      
      let currentY = tableTop;
      
      // Desenhar cabeçalho
      doc.fontSize(10).font('Helvetica-Bold');
      tableHeaders.forEach((header, i) => {
        const x = 50 + columnWidths.slice(0, i).reduce((acc, width) => acc + width, 0);
        doc.text(header, x, currentY);
      });
      
      currentY += 20;
      doc.moveTo(50, currentY).lineTo(550, currentY).stroke();
      currentY += 10;
      
      // Desenhar linhas da tabela
      doc.font('Helvetica');
      movements.forEach((movement, index) => {
        // Verificar se precisa de nova página
        if (currentY > 700) {
          doc.addPage();
          currentY = 50;
        }
        
        const date = new Date(movement.data).toLocaleDateString('pt-BR');
        const productName = movement.produto ? movement.produto.nome : 'N/A';
        const tipo = movement.tipo === 'entrada' ? 'Entrada' : movement.tipo === 'saida' ? 'Saída' : 'Ajuste';
        const responsavel = movement.responsavel ? movement.responsavel.nome : 'N/A';
        
        doc.text(date, 50, currentY);
        doc.text(productName.substring(0, 25) + (productName.length > 25 ? '...' : ''), 50 + columnWidths[0], currentY);
        doc.text(tipo, 50 + columnWidths[0] + columnWidths[1], currentY);
        doc.text(movement.quantidade.toString(), 50 + columnWidths[0] + columnWidths[1] + columnWidths[2], currentY);
        doc.text(responsavel.substring(0, 15) + (responsavel.length > 15 ? '...' : ''), 50 + columnWidths[0] + columnWidths[1] + columnWidths[2] + columnWidths[3], currentY);
        doc.text((movement.motivo || '').substring(0, 15) + (movement.motivo && movement.motivo.length > 15 ? '...' : ''), 50 + columnWidths[0] + columnWidths[1] + columnWidths[2] + columnWidths[3] + columnWidths[4], currentY);
        
        currentY += 20;
        
        // Linha divisória entre movimentações
        if (index < movements.length - 1) {
          doc.moveTo(50, currentY - 10).lineTo(550, currentY - 10).stroke();
        }
      });
      
      // Rodapé
      doc.fontSize(10).text('Estoque Uninassau - Sistema de Controle de Estoque', 50, 750, { align: 'center' });
      
      doc.end();
      
      stream.on('finish', () => {
        resolve();
      });
      
      stream.on('error', (err) => {
        reject(err);
      });
    } catch (error) {
      reject(error);
    }
  });
};

// Função auxiliar para gerar PDF de vencimentos
const generateExpiryPDF = async (expired, nearExpiry, daysAhead, filePath) => {
  return new Promise((resolve, reject) => {
    try {
      // Criar diretório temp se não existir
      const dir = path.dirname(filePath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      
      const doc = new PDFDocument({ margin: 50 });
      const stream = fs.createWriteStream(filePath);
      
      doc.pipe(stream);
      
      // Título
      doc.fontSize(20).text('Relatório de Vencimentos', { align: 'center' });
      doc.moveDown();
      
      // Data do relatório
      doc.fontSize(12).text(`Data: ${new Date().toLocaleDateString('pt-BR')} ${new Date().toLocaleTimeString('pt-BR')}`, { align: 'right' });
      doc.moveDown();
      
      // Resumo
      doc.fontSize(14).text('Resumo', { underline: true });
      doc.fontSize(12).text(`Produtos Vencidos: ${expired.length}`);
      doc.text(`Produtos a Vencer (próximos ${daysAhead} dias): ${nearExpiry.length}`);
      doc.moveDown();
      
      // Produtos vencidos
      doc.fontSize(14).text('Produtos Vencidos', { underline: true });
      doc.moveDown();
      
      if (expired.length === 0) {
        doc.fontSize(12).text('Nenhum produto vencido.');
        doc.moveDown();
      } else {
        // Cabeçalho da tabela
        const tableTop = doc.y;
        const tableHeaders = ['Código', 'Nome', 'Categoria', 'Qtd', 'Validade', 'Dias Vencido'];
        const columnWidths = [70, 150, 100, 40, 70, 70];
        
        let currentY = tableTop;
        
        // Desenhar cabeçalho
        doc.fontSize(10).font('Helvetica-Bold');
        tableHeaders.forEach((header, i) => {
          const x = 50 + columnWidths.slice(0, i).reduce((acc, width) => acc + width, 0);
          doc.text(header, x, currentY);
        });
        
        currentY += 20;
        doc.moveTo(50, currentY).lineTo(550, currentY).stroke();
        currentY += 10;
        
        // Desenhar linhas da tabela
        doc.font('Helvetica');
        expired.forEach((product, index) => {
          // Verificar se precisa de nova página
          if (currentY > 700) {
            doc.addPage();
            currentY = 50;
          }
          
          const expiryDate = new Date(product.dataValidade);
          const today = new Date();
          const diffTime = today - expiryDate;
          const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
          
          doc.text(product.codigo || '-', 50, currentY);
          doc.text(product.nome.substring(0, 25) + (product.nome.length > 25 ? '...' : ''), 50 + columnWidths[0], currentY);
          doc.text(product.categoria, 50 + columnWidths[0] + columnWidths[1], currentY);
          doc.text(product.quantidade.toString(), 50 + columnWidths[0] + columnWidths[1] + columnWidths[2], currentY);
          doc.text(expiryDate.toLocaleDateString('pt-BR'), 50 + columnWidths[0] + columnWidths[1] + columnWidths[2] + columnWidths[3], currentY);
          doc.text(diffDays.toString(), 50 + columnWidths[0] + columnWidths[1] + columnWidths[2] + columnWidths[3] + columnWidths[4], currentY);
          
          currentY += 20;
          
          // Linha divisória entre produtos
          if (index < expired.length - 1) {
            doc.moveTo(50, currentY - 10).lineTo(550, currentY - 10).stroke();
          }
        });
      }
      
      doc.moveDown();
      
      // Produtos a vencer
      doc.fontSize(14).text(`Produtos a Vencer (próximos ${daysAhead} dias)`, { underline: true });
      doc.moveDown();
      
      if (nearExpiry.length === 0) {
        doc.fontSize(12).text(`Nenhum produto a vencer nos próximos ${daysAhead} dias.`);
        doc.moveDown();
      } else {
        // Cabeçalho da tabela
        const tableTop = doc.y;
        const tableHeaders = ['Código', 'Nome', 'Categoria', 'Qtd', 'Validade', 'Dias Restantes'];
        const columnWidths = [70, 150, 100, 40, 70, 70];
        
        let currentY = tableTop;
        
        // Desenhar cabeçalho
        doc.fontSize(10).font('Helvetica-Bold');
        tableHeaders.forEach((header, i) => {
          const x = 50 + columnWidths.slice(0, i).reduce((acc, width) => acc + width, 0);
          doc.text(header, x, currentY);
        });
        
        currentY += 20;
        doc.moveTo(50, currentY).lineTo(550, currentY).stroke();
        currentY += 10;
        
        // Desenhar linhas da tabela
        doc.font('Helvetica');
        nearExpiry.forEach((product, index) => {
          // Verificar se precisa de nova página
          if (currentY > 700) {
            doc.addPage();
            currentY = 50;
          }
          
          const expiryDate = new Date(product.dataValidade);
          const today = new Date();
          const diffTime = expiryDate - today;
          const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
          
          doc.text(product.codigo || '-', 50, currentY);
          doc.text(product.nome.substring(0, 25) + (product.nome.length > 25 ? '...' : ''), 50 + columnWidths[0], currentY);
          doc.text(product.categoria, 50 + columnWidths[0] + columnWidths[1], currentY);
          doc.text(product.quantidade.toString(), 50 + columnWidths[0] + columnWidths[1] + columnWidths[2], currentY);
          doc.text(expiryDate.toLocaleDateString('pt-BR'), 50 + columnWidths[0] + columnWidths[1] + columnWidths[2] + columnWidths[3], currentY);
          doc.text(diffDays.toString(), 50 + columnWidths[0] + columnWidths[1] + columnWidths[2] + columnWidths[3] + columnWidths[4], currentY);
          
          currentY += 20;
          
          // Linha divisória entre produtos
          if (index < nearExpiry.length - 1) {
            doc.moveTo(50, currentY - 10).lineTo(550, currentY - 10).stroke();
          }
        });
      }
      
      // Rodapé
      doc.fontSize(10).text('Estoque Uninassau - Sistema de Controle de Estoque', 50, 750, { align: 'center' });
      
      doc.end();
      
      stream.on('finish', () => {
        resolve();
      });
      
      stream.on('error', (err) => {
        reject(err);
      });
    } catch (error) {
      reject(error);
    }
  });
};

module.exports = {
  generateStockReport,
  generateMovementsReport,
  generateExpiryReport
};
