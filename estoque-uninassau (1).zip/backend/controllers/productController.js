const Product = require('../models/productModel');
const StockMovement = require('../models/stockMovementModel');

// @desc    Criar um novo produto
// @route   POST /api/products
// @access  Private
const createProduct = async (req, res) => {
  try {
    const {
      nome,
      codigo,
      categoria,
      fornecedor,
      precoCusto,
      precoVenda,
      quantidade,
      estoqueMinimo,
      dataFabricacao,
      dataValidade,
      localizacao,
      descricao
    } = req.body;

    // Verificar se o código já existe
    if (codigo) {
      const existingProduct = await Product.findOne({ codigo });
      if (existingProduct) {
        return res.status(400).json({ message: 'Produto com este código já existe' });
      }
    }

    // Criar o produto
    const product = await Product.create({
      nome,
      codigo,
      categoria,
      fornecedor,
      precoCusto,
      precoVenda,
      quantidade,
      estoqueMinimo,
      dataFabricacao,
      dataValidade,
      localizacao,
      descricao,
      criadoPor: req.user._id
    });

    // Se houver quantidade inicial, registrar como entrada no estoque
    if (quantidade > 0) {
      await StockMovement.create({
        produto: product._id,
        tipo: 'entrada',
        quantidade,
        responsavel: req.user._id,
        motivo: 'Cadastro inicial',
        observacao: 'Quantidade inicial do produto'
      });
    }

    res.status(201).json(product);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Obter todos os produtos
// @route   GET /api/products
// @access  Private
const getProducts = async (req, res) => {
  try {
    const pageSize = 10;
    const page = Number(req.query.page) || 1;
    
    const keyword = req.query.keyword
      ? {
          nome: {
            $regex: req.query.keyword,
            $options: 'i'
          }
        }
      : {};
      
    const categoria = req.query.categoria
      ? { categoria: req.query.categoria }
      : {};
      
    const count = await Product.countDocuments({ ...keyword, ...categoria });
    
    const products = await Product.find({ ...keyword, ...categoria })
      .limit(pageSize)
      .skip(pageSize * (page - 1))
      .sort({ nome: 1 });
    
    res.json({
      products,
      page,
      pages: Math.ceil(count / pageSize),
      total: count
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Obter um produto pelo ID
// @route   GET /api/products/:id
// @access  Private
const getProductById = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    
    if (product) {
      res.json(product);
    } else {
      res.status(404).json({ message: 'Produto não encontrado' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Atualizar um produto
// @route   PUT /api/products/:id
// @access  Private
const updateProduct = async (req, res) => {
  try {
    const {
      nome,
      codigo,
      categoria,
      fornecedor,
      precoCusto,
      precoVenda,
      estoqueMinimo,
      dataFabricacao,
      dataValidade,
      localizacao,
      descricao
    } = req.body;

    const product = await Product.findById(req.params.id);
    
    if (!product) {
      return res.status(404).json({ message: 'Produto não encontrado' });
    }
    
    // Verificar se o código já existe em outro produto
    if (codigo && codigo !== product.codigo) {
      const existingProduct = await Product.findOne({ codigo });
      if (existingProduct) {
        return res.status(400).json({ message: 'Produto com este código já existe' });
      }
    }
    
    // Atualizar os campos
    product.nome = nome || product.nome;
    product.codigo = codigo || product.codigo;
    product.categoria = categoria || product.categoria;
    product.fornecedor = fornecedor || product.fornecedor;
    product.precoCusto = precoCusto || product.precoCusto;
    product.precoVenda = precoVenda || product.precoVenda;
    product.estoqueMinimo = estoqueMinimo || product.estoqueMinimo;
    product.dataFabricacao = dataFabricacao || product.dataFabricacao;
    product.dataValidade = dataValidade || product.dataValidade;
    product.localizacao = localizacao || product.localizacao;
    product.descricao = descricao || product.descricao;
    product.ultimaAtualizacao = Date.now();
    
    const updatedProduct = await product.save();
    
    res.json(updatedProduct);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Excluir um produto
// @route   DELETE /api/products/:id
// @access  Private/Admin
const deleteProduct = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    
    if (!product) {
      return res.status(404).json({ message: 'Produto não encontrado' });
    }
    
    // Verificar se há movimentações para este produto
    const movementCount = await StockMovement.countDocuments({ produto: req.params.id });
    
    if (movementCount > 0) {
      return res.status(400).json({ 
        message: 'Não é possível excluir este produto pois existem movimentações associadas a ele' 
      });
    }
    
    await product.deleteOne();
    
    res.json({ message: 'Produto removido' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Obter produtos com estoque baixo
// @route   GET /api/products/low-stock
// @access  Private
const getLowStockProducts = async (req, res) => {
  try {
    const products = await Product.find({
      $expr: { $lte: ["$quantidade", "$estoqueMinimo"] }
    });
    
    res.json(products);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Obter produtos próximos ao vencimento ou vencidos
// @route   GET /api/products/expiry
// @access  Private
const getExpiryProducts = async (req, res) => {
  try {
    const today = new Date();
    const thirtyDaysFromNow = new Date();
    thirtyDaysFromNow.setDate(today.getDate() + 30);
    
    const products = await Product.find({
      dataValidade: { 
        $ne: null,
        $lte: thirtyDaysFromNow 
      }
    }).sort({ dataValidade: 1 });
    
    // Separar produtos vencidos e a vencer
    const expired = products.filter(p => new Date(p.dataValidade) < today);
    const nearExpiry = products.filter(p => new Date(p.dataValidade) >= today);
    
    res.json({
      expired,
      nearExpiry
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Obter categorias de produtos
// @route   GET /api/products/categories
// @access  Private
const getProductCategories = async (req, res) => {
  try {
    const categories = await Product.distinct('categoria');
    res.json(categories);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  createProduct,
  getProducts,
  getProductById,
  updateProduct,
  deleteProduct,
  getLowStockProducts,
  getExpiryProducts,
  getProductCategories
};
