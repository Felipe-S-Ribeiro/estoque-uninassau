const StockMovement = require('../models/stockMovementModel');
const Product = require('../models/productModel');

// @desc    Registrar movimentação de estoque (entrada, saída ou ajuste)
// @route   POST /api/stock
// @access  Private
const registerStockMovement = async (req, res) => {
  try {
    const { produto, tipo, quantidade, motivo, observacao } = req.body;

    // Verificar se o produto existe
    const productExists = await Product.findById(produto);
    if (!productExists) {
      return res.status(404).json({ message: 'Produto não encontrado' });
    }

    // Validar quantidade
    if (quantidade <= 0) {
      return res.status(400).json({ message: 'A quantidade deve ser maior que zero' });
    }

    // Validar estoque disponível para saída
    if (tipo === 'saida' && productExists.quantidade < quantidade) {
      return res.status(400).json({ message: 'Quantidade insuficiente em estoque' });
    }

    // Criar a movimentação
    const stockMovement = await StockMovement.create({
      produto,
      tipo,
      quantidade,
      responsavel: req.user._id,
      motivo,
      observacao
    });

    // Atualizar quantidade do produto
    if (tipo === 'entrada') {
      productExists.quantidade += quantidade;
    } else if (tipo === 'saida') {
      productExists.quantidade -= quantidade;
    } else if (tipo === 'ajuste') {
      // Para ajuste, a quantidade informada é o novo valor total
      productExists.quantidade = quantidade;
    }

    productExists.ultimaAtualizacao = Date.now();
    await productExists.save();

    res.status(201).json(stockMovement);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Obter todas as movimentações de estoque
// @route   GET /api/stock
// @access  Private
const getStockMovements = async (req, res) => {
  try {
    const pageSize = 10;
    const page = Number(req.query.page) || 1;
    
    // Filtros
    const filters = {};
    
    if (req.query.produto) {
      filters.produto = req.query.produto;
    }
    
    if (req.query.tipo) {
      filters.tipo = req.query.tipo;
    }
    
    if (req.query.responsavel) {
      filters.responsavel = req.query.responsavel;
    }
    
    // Filtro por data
    if (req.query.dataInicio || req.query.dataFim) {
      filters.data = {};
      
      if (req.query.dataInicio) {
        filters.data.$gte = new Date(req.query.dataInicio);
      }
      
      if (req.query.dataFim) {
        filters.data.$lte = new Date(req.query.dataFim);
        // Ajustar para o final do dia
        filters.data.$lte.setHours(23, 59, 59, 999);
      }
    }
    
    const count = await StockMovement.countDocuments(filters);
    
    const movements = await StockMovement.find(filters)
      .populate('produto', 'nome codigo')
      .populate('responsavel', 'nome')
      .limit(pageSize)
      .skip(pageSize * (page - 1))
      .sort({ data: -1 });
    
    res.json({
      movements,
      page,
      pages: Math.ceil(count / pageSize),
      total: count
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Obter movimentações de um produto específico
// @route   GET /api/stock/product/:id
// @access  Private
const getProductMovements = async (req, res) => {
  try {
    const movements = await StockMovement.find({ produto: req.params.id })
      .populate('responsavel', 'nome')
      .sort({ data: -1 });
    
    res.json(movements);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Obter resumo de movimentações (para dashboard)
// @route   GET /api/stock/summary
// @access  Private
const getMovementsSummary = async (req, res) => {
  try {
    // Obter data de 30 dias atrás
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    // Total de movimentações nos últimos 30 dias
    const totalMovements = await StockMovement.countDocuments({
      data: { $gte: thirtyDaysAgo }
    });
    
    // Total por tipo
    const entriesCount = await StockMovement.countDocuments({
      tipo: 'entrada',
      data: { $gte: thirtyDaysAgo }
    });
    
    const exitsCount = await StockMovement.countDocuments({
      tipo: 'saida',
      data: { $gte: thirtyDaysAgo }
    });
    
    const adjustmentsCount = await StockMovement.countDocuments({
      tipo: 'ajuste',
      data: { $gte: thirtyDaysAgo }
    });
    
    // Últimas 5 movimentações
    const recentMovements = await StockMovement.find()
      .populate('produto', 'nome codigo')
      .populate('responsavel', 'nome')
      .sort({ data: -1 })
      .limit(5);
    
    res.json({
      totalMovements,
      entriesCount,
      exitsCount,
      adjustmentsCount,
      recentMovements
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  registerStockMovement,
  getStockMovements,
  getProductMovements,
  getMovementsSummary
};
