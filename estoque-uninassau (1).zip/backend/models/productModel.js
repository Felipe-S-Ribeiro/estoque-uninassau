const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  nome: {
    type: String,
    required: [true, 'Nome do produto é obrigatório'],
    trim: true
  },
  codigo: {
    type: String,
    trim: true,
    unique: true
  },
  categoria: {
    type: String,
    required: [true, 'Categoria é obrigatória'],
    trim: true
  },
  fornecedor: {
    type: String,
    trim: true
  },
  precoCusto: {
    type: Number,
    required: [true, 'Preço de custo é obrigatório'],
    min: 0
  },
  precoVenda: {
    type: Number,
    required: [true, 'Preço de venda é obrigatório'],
    min: 0
  },
  quantidade: {
    type: Number,
    required: [true, 'Quantidade é obrigatória'],
    default: 0,
    min: 0
  },
  estoqueMinimo: {
    type: Number,
    default: 5,
    min: 0
  },
  dataFabricacao: {
    type: Date
  },
  dataValidade: {
    type: Date
  },
  localizacao: {
    type: String,
    trim: true
  },
  descricao: {
    type: String,
    trim: true
  },
  criadoPor: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  dataCriacao: {
    type: Date,
    default: Date.now
  },
  ultimaAtualizacao: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

// Método para verificar se o produto está com estoque baixo
productSchema.methods.isLowStock = function() {
  return this.quantidade <= this.estoqueMinimo;
};

// Método para verificar se o produto está vencido
productSchema.methods.isExpired = function() {
  if (!this.dataValidade) return false;
  return new Date() > this.dataValidade;
};

// Método para verificar se o produto está próximo do vencimento (30 dias)
productSchema.methods.isNearExpiry = function() {
  if (!this.dataValidade) return false;
  
  const today = new Date();
  const expiryDate = new Date(this.dataValidade);
  const diffTime = expiryDate - today;
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
  return diffDays >= 0 && diffDays <= 30;
};

const Product = mongoose.model('Product', productSchema);

module.exports = Product;
