const mongoose = require('mongoose');

const stockMovementSchema = new mongoose.Schema({
  produto: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Product',
    required: true
  },
  tipo: {
    type: String,
    enum: ['entrada', 'saida', 'ajuste'],
    required: true
  },
  quantidade: {
    type: Number,
    required: true
  },
  responsavel: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  motivo: {
    type: String,
    trim: true
  },
  observacao: {
    type: String,
    trim: true
  },
  data: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

const StockMovement = mongoose.model('StockMovement', stockMovementSchema);

module.exports = StockMovement;
