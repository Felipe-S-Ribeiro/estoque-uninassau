const express = require('express');
const router = express.Router();
const { 
  generateStockReport, 
  generateMovementsReport, 
  generateExpiryReport 
} = require('../controllers/reportController');
const { protect } = require('../middleware/authMiddleware');

// Rotas protegidas para todos os usuários
router.route('/stock')
  .get(protect, generateStockReport);

router.route('/movements')
  .get(protect, generateMovementsReport);

router.route('/expiry')
  .get(protect, generateExpiryReport);

module.exports = router;
