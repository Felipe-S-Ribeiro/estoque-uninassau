const express = require('express');
const router = express.Router();
const { 
  registerStockMovement, 
  getStockMovements, 
  getProductMovements, 
  getMovementsSummary 
} = require('../controllers/stockController');
const { protect, admin } = require('../middleware/authMiddleware');

// Rotas protegidas para todos os usuários
router.route('/')
  .post(protect, registerStockMovement)
  .get(protect, getStockMovements);

router.route('/summary')
  .get(protect, getMovementsSummary);

router.route('/product/:id')
  .get(protect, getProductMovements);

module.exports = router;
