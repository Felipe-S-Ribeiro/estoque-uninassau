const express = require('express');
const router = express.Router();
const { 
  registerUser, 
  loginUser, 
  getUserProfile, 
  updateUserProfile, 
  getUsers 
} = require('../controllers/userController');
const { protect, admin } = require('../middleware/authMiddleware');

// Rotas públicas
router.post('/register', registerUser);
router.post('/login', loginUser);

// Rotas protegidas
router.route('/profile')
  .get(protect, getUserProfile)
  .put(protect, updateUserProfile);

// Rotas de administrador
router.route('/')
  .get(protect, admin, getUsers);

module.exports = router;
