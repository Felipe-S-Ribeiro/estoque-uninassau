const express = require('express');
const router = express.Router();
const { 
  createProduct, 
  getProducts, 
  getProductById, 
  updateProduct, 
  deleteProduct,
  getLowStockProducts,
  getExpiryProducts,
  getProductCategories
} = require('../controllers/productController');
const { protect, admin } = require('../middleware/authMiddleware');

// Rotas protegidas para todos os usuários
router.route('/')
  .post(protect, createProduct)
  .get(protect, getProducts);

router.route('/low-stock')
  .get(protect, getLowStockProducts);

router.route('/expiry')
  .get(protect, getExpiryProducts);

router.route('/categories')
  .get(protect, getProductCategories);

router.route('/:id')
  .get(protect, getProductById)
  .put(protect, updateProduct)
  .delete(protect, admin, deleteProduct); // Apenas admin pode excluir

module.exports = router;
